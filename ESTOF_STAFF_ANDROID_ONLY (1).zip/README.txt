ESTOF STAFF Android only

Questo progetto apre direttamente:
https://estof.it/staff-app/

Per trasformarlo in APK:
1. apri il progetto in un ambiente Android
2. build apk
3. installa il file APK su Android

URL da cambiare:
app/src/main/java/it/estof/staffapp/MainActivity.kt
